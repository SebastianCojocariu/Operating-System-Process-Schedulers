//package schedulers;
public class WeightedScheduler extends SchedulerTasks {
    //cota at which need to be verified all the "aparitions" of processes.
    int t;
    //array of cote for each process.
    int[] cote;
    int moment = 0;
    
    //method to find cmmdc of 2 integer numbers.
    int cmmdc(int a, int b) {
        if (a == 0 || b == 0) return 0;
        while (a > 0 && b > 0) {
            int r = b;
            b = a % b;
            a = r;
        }
        return a + b;
    }
   //method to get the cotes for each process and storing them in cote[],but also to
   //find t. 
    void getCota() {
        cote=new int[super.processes.length];
        int suma = 0;
        int divizor = processes[0].weight;
        for (int i = 0; i < processes.length; i++) {
            suma += processes[i].weight;
            divizor = cmmdc(divizor, processes[i].weight);
        }
        t = suma / divizor;
        for (int i = 0; i < processes.length; i++) {
            cote[i] = processes[i].weight / divizor;
        }
    }

/**
 * Returns if at the moment specified bymoment ,there exists a process whose cota is <0.
 *
 * @param
 * @return 1 if at the moment specified by moment,there is no process whose cota is <0,and 0 otherwise
 * @see getCota()
 */

    int test() {
        for (int i = 0; i < processes.length; i++)
            if (cote[i] < 0)
                return 0;
        return 1;
    }

/**
 * Returns the index of the process to be checked on the Processes array
 * having into consideration the result of the test() method.
 *
 * @param
 * @return the index of the process to be checked
 * @see test()
 */

    public int getIndexProcess() {
            if (moment == 0)
                getCota();
            int random_process_index = (int)(Math.random()*processes.length);
            cote[random_process_index]--;
            while (test() == 0) {
                cote[random_process_index]++;
                random_process_index = (int)(Math.random()*processes.length);
                cote[random_process_index]--;
            }

            moment++;
            if (moment % t == 0)
                getCota();
            return random_process_index;


    }
}
