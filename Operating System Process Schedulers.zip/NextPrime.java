//package processes;
 
public class NextPrime extends Processes {

/**
 * Returns the next prime number of the number passed as parameter.
 *
 * @param n an integer number
 * @return the next prime number greater than the number passed as parameter if
 * the number is greater of equal to 2,-1 otherwise
 */
 
      public int function(int n) {
        if (n < 2)
            return 2;

            CheckPrime check=new CheckPrime();
            for (int i = n + 1; i <= 2 * (n + 1); i++) {
               if(check.function(i)==1)
                   return i;
            }
            //caz in care nu se va ajunge din Postulandul lui Bertrand
            //intre n si 2*n se gaseste sigur un nr prim,pt orice n natural nenul
            return -1;
        }
}
