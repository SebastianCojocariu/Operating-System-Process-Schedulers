//package cache;

public class LfuCache extends CacheTypes{

    public LfuCache(int n){
        this.capacity=n;
    }

/**
 * Returns an integer number representing the value of the processName and input
 * specified by key found in list.If found,increment the hits.
 
 * @param key the key which will be used to search in the list
 * @return value of the processName and input if found in list,else null
 * @see Key
 */
    public Integer getValue(Key key){
        for(Key cheie:list) {
            if (cheie.processName.equals(key.processName) && cheie.input == key.input){
                cheie.hits++;
                return cheie.value;
            }
        }
        return null;
    }

/**
 * Remove the node from the list which have the less number of hits.
 
 * @param
 * @return 
 * @see Key
 */

   public void remove() {
        int min = list.get(0).hits;
        int index = 0;
        int i=0;
        for (Key key:list) {
            if (key.hits < min) {
                min = key.hits;
                index = i;
            }
            i++;
        }
        list.remove(index);
    }

/**
 * Add the key passed as parameter to the list.If the list is full,will remove
 * a node using remove().Then the key will be added to the list.
 
 * @param key the key which will be added to the list
 * @return 
 * @see Key
 */

    public void add(Key key){
	int index = getIndex(key);
        if (index < 0){
        
        if(capacity==list.size())
            remove();
	
        list.add(key);
        }
	
    }

   }
