//package schedulers;

public class RoundRobinScheduler extends  SchedulerTasks{
    //array containing the frequency of each existing process.
    int[] frequency;

    //constructor
     public RoundRobinScheduler(int n){
        frequency=new int[n];
        for(int i=0;i<n;i++)
            frequency[i]=0;
    }
/**
 * Returns if the frequencies of all processes differ by at most 2.
 *
 * @param
 * @return 1 if the frequencies of all processes differ by at most 2,0 otherwise
 */
    int test(){
        for(int i=0;i<processes.length;i++)
            for(int j=i+1;j<processes.length;j++)
                if(Math.abs(frequency[i]-frequency[j])>=2)
                    return 0;
        return 1;
    }

/**
 * Returns the index of the process to be checked on the Processes array
 * having into consideration the result of the test() method.
 *
 * @param
 * @return the index of the process to be checked
 * @see test()
 */
     public int getIndexProcess() {
        int random=(int)(Math.random()*processes.length);
        frequency[random]++;
        while(test()==0){
            frequency[random]--;
            random=(int)(Math.random()*processes.length);
            frequency[random]++;
        }
        return random;
     }

}
