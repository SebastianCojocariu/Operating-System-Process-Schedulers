//package processes;

public class CheckPrime extends Processes {

/**
 * Returns if the number passed as parameter is prime or not.
 *
 * @param n an integer number
 * @return 1 if n is prime and 0 otherwise
 */

    public int function(int n){
            if(n<2)
                return 0;

            if(n==2)
                return 1;

            else
                for(int i=2;i<=Math.sqrt(n);i++)
                    if(n%i==0)
                        return 0;
            return 1;
        }
    }

