//package schedulers;

public class RandomScheduler extends SchedulerTasks{
/**
 * Returns the index of the process to be checked on the Processes array,randomly.
 *
 * @param
 * @return the index of the process to be checked
 * @see SchedulerTasks
 */
 
    public int getIndexProcess(){
            return (int)(Math.random()*processes.length);
    }
}
