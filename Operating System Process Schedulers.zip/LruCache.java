//package cache;

public class LruCache extends CacheTypes{
    public LruCache(int n){
        this.capacity=n;
    }
/**
 * Returns an integer number representing the value of the processName and input
 * specified by key found in list.If found,will remove the node containing it and
 * will add again the key at the end of the list.
 
 * @param key the key which will be used to search in the list
 * @return value of the processName and input if found in list,else null
 * @see Key
 */

   public Integer getValue(Key key){
        int index=0;
        for(Key cheie:list) {
            if (cheie.processName.equals(key.processName) && cheie.input == key.input){
                int value=cheie.value;
                list.remove(index);
                key.value=value;
                list.add(key);
                return value;
            }
            index++;
        }
        return null;
    }



/**
 * Add the key passed as parameter to the list.If there is a key with the same processName
 * and input,will move the node containing it at the end of the list. 
 
 * @param key the key which will be added to the list
 * @return 
 * @see Key
 */
   public void add(Key key) {
        int index = getIndex(key);
        if (index >= 0)
            list.remove(index);

        if (list.size() == capacity)
                list.remove(0);

        list.add(key);

        }

    }
