//import processes.*;
//import PooCbTema1.InputOutput.*;
//import cache.*;
//import schedulers.*;
import java.util.*;

public class MainClass {
    public static void main(String[] args) {
        //citim datele din fisier.        
	HomeworkReader reader = new HomeworkReader(args[0]);
        ProblemData date = reader.readData();
        reader.close();
        //
        
        //completam vectorul de procese si de inputuri existente in fisier.
        HomeworkWriter writer=new HomeworkWriter(args[1]);

        Processes[] v = Processes.getProcesses(date);
        int[] inputs=date.getNumbersToBeProcessed();
        //

        //trebuie selectat tipul de scheduler
        SchedulerTasks scheduler;
        int numberProcesses=date.getProcesses().length;
        String schedulerType=date.getSchedulerType();
        
        if(schedulerType.equals("RandomScheduler"))
            scheduler=new RandomScheduler();
        else if(schedulerType.equals("RoundRobinScheduler"))
            scheduler=new RoundRobinScheduler(numberProcesses);
        else
            scheduler=new WeightedScheduler();
        scheduler.processes=v;
        //
        
        //alegem tipul de cache din input

        CacheTypes cache=null;
        
       
        int capacity=date.getCacheCapacity();
        String cacheType=date.getCacheType();
        
        if(cacheType.equals("NoCache"))
            cache=new NoCache(capacity);
        else if(cacheType.equals("LruCache"))
            cache=new LruCache(capacity);
        else if(cacheType.equals("LfuCache"))
            cache=new LfuCache(capacity);
	//


       //pentru fiecare input
       for(int i=0;i<inputs.length;i++){
           
           //generam un index pentru a selecta un proces,in concordanta cu tipul de scheduler citit
           //din fisier.
           
           int indexScheduler=scheduler.getIndexProcess();
           Key key=new Key(v[indexScheduler].getClass().toString(),inputs[i]);
	   
	   //cautam in cache procesul cu inputul gasit.	
           int indexCache=cache.getIndex(key);
           
           //daca am gasit in cache,luam valoarea din cache.
           if(indexCache>=0){
               int value=cache.getValue(key);
               String processName=key.processName.substring(6);
               writer.println(inputs[i]+" "+processName+" "+value+" FromCache");
           }
           
           //daca nu am gasit in cache,generam noi rezultatul si il punem in cache.
           else{
               int rez=v[indexScheduler].function(inputs[i]);
               key.value=rez;
               cache.add(key);
               String processName=key.processName.substring(6);
               writer.println(inputs[i]+" "+processName+" "+key.value+" Computed");

           }
        }
        writer.close();

    }

}


