//package cache;
 
public class Key {
 //the name of the process.
    public String processName;
 //the input for the process.
    public int input;
 //the result of the process(input).
    public int value;
 //number of "hits" of the value,that is the number of accessing this value.
    public int hits;


   //constructor with 2 parameters.
    public Key(String processName,int input){
        this.processName=processName;
        this.input=input;
    }
   //constructor with 3 parameters.
    public Key(String processName,int input,int value){
        this.processName=processName;
        this.input=input;
        this.value=value;
    }

}
