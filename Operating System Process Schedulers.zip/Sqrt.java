//package processes;

public class Sqrt extends   Processes{
   
/**
 * Returns the radical of the number passed as parameter,casted to integer.
 *
 * @param n an integer number
 * @return the radical of the number passed as parameter,casted to integer
 */

    public int function(int n){
        return (int)Math.floor(Math.sqrt(Math.abs(n)));
    }
}
