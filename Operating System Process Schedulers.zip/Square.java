//package processes;

public class Square extends Processes{
    
/**
 * Returns the square of the number passed as parameter.
 *
 * @param n an integer number
 * @return the square of the number passed as parameter
 */
    public int function(int n){
            return (int)Math.pow(n,2);
    }
}
