//package processes;

public class Cube extends Processes {

/**
 * Returns the cube of the number passed as parameter.
 *
 * @param n an integer number.
 * @return the cube of the number n.
 */
 
    public int function(int n) {
        return (int)Math.pow(n,3);
    }
}
