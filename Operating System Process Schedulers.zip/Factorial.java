//package processes;
  
public class Factorial extends Processes{

/**
 * Returns the factorial of the number passed as parameter modulo 9973.
 *
 * @param n an integer number
 * @return n!(modulo 9973)
 */
    public int function(int n){
        if(n<0)
            return 0;
        if(n==0||n==1) return 1;
        int product=1;
        for(int i=2;i<=n;i++){
            product=(i%modulo*product)%modulo;
        }
        return product;
    }
}
