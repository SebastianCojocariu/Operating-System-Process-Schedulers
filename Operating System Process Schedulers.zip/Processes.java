//package processes;
public abstract class Processes{
    //weight of the process specified by processName.
    public int weight;
    //the name of the process.
    public String processName;

    final static int modulo = 9973;
    public abstract int function(int n);

/**
 * Returns an array of Processes,according to the ProblemData Object passed
 * as parameter.A cast for each such process will be done according to their 
 * type.
 *
 * @param date ProblemData Object containing information about the processes
 * to be done
 * @return an array of Processes
 * @see ProblemData
 */


    public static Processes[] getProcesses(ProblemData date) {
        int length = date.getProcesses().length;
        Processes[] v = new Processes[length];
        for (int i = 0; i < length; i++) {
            String process = date.getProcesses()[i].getType();
            if (process.equals("CheckPrime")) {
                v[i] = new CheckPrime();
                v[i].processName = "class CheckPrime";
            }
            else if (process.equals("NextPrime")) {
                v[i] = new NextPrime();
                v[i].processName = "class NextPrime";
            }
            else if (process.equals("Cube")) {
                v[i] = new Cube();
                v[i].processName = "class Cube";
            }

            else if (process.equals("Fibonacci")) {
                v[i] = new Fibonacci();
                v[i].processName = "class Fibonacci";
            }

            else if (process.equals("Sqrt")) {
                v[i] = new Sqrt();
                v[i].processName = "class Sqrt";
            }
            else if (process.equals("Square")) {
                v[i] = new Square();
                v[i].processName = "class Square";
            }
            else if (process.equals("Factorial")) {
                v[i] = new Factorial();
                v[i].processName = "class Factorial";
            }

            v[i].weight = date.getProcesses()[i].getWeight();
        }
        return v;
    }
}
