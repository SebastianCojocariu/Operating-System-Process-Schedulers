//package schedulers;
//import processes.*;

public abstract class SchedulerTasks {
    //array of Processes containing all processes to be checked.
    public Processes[] processes;
    //method to get the index of the process to be checked.
    public abstract int getIndexProcess();
}
