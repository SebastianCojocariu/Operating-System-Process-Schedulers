//package cache;

import java.util.*;
/**
 * An abstract class which will be extended by other 3 classes
 * representing the types of cache available:NoCache,LruCache,LfuCache.
 */
 public abstract class CacheTypes{
    LinkedList<Key> list=new LinkedList<Key>();
    int capacity;
/**
 * Add the key passed as parameter in the list.
 
 * @param key the key to be added in the list
 * @return nothing
 */
    public abstract void add(Key key);

/**
 * Returns an integer number representing the value of the processName and input
 * specified by key found in list.
 
 * @param key the key which will be used to search in the list
 * @return value of the processName and input if found in list,else null
 * @see Key
 */

    public abstract Integer getValue(Key key);

/**
 * Returns an integer number representing the index at which we can find 
 * the specified key passed as argument(the key is important only by processName 
 * and input,and not by value or hits).If not found,will return -1.
 
 * @param key an object of type Key which will provide a way to assert if
 * cache contains (processName,input) specified by it
 * @return the index of the processName and input specified by key,or -1 if not found
 * @see Key
 */

    public int getIndex(Key key){
        int index=0;
        for(Key cheie:list) {
            if (cheie.processName.equals(key.processName) && cheie.input == key.input){
                return index;
            }
            index++;
        }
        return -1;

    }

}
