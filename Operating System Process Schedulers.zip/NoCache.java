//package cache;

public class NoCache extends CacheTypes {
    //constructor.
    public NoCache(int n){
        this.capacity=n;
    }

    public void add(Key key){}
    public Integer getValue(Key key){
        return null;
    }
}
