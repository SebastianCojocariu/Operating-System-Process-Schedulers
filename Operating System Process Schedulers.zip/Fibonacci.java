//package processes;

public class Fibonacci extends Processes{

/**
 * Returns the nth number Fibonacci,modulo 9973,where n is
 * the argument passed as parameter.
 *
 * @param n an integer number
 * @return the nth number Fibonacci,modulo 9973
 */
    public int function(int n){
        if(n<0)
            return -1;
        if(n==0) return 0;
        if(n==1) return 1;
        int a=0,b=1;
        for(int i=0;i<n-1;i++)
        {
            int x=b%modulo;
            b=(a%modulo+b%modulo)%modulo;
            a=x;
        }
        return b;
    }
}
